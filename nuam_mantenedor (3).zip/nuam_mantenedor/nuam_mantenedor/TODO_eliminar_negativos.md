# TODO: Eliminar números negativos en formulario de crear calificación

## Pasos a completar:
Actualizar nuam_mantenedor/calificaciones/forms.py para agregar widgets con atributos min a campos numéricos:
anio_tributario: min="1900", max="2030"
monto: min="0"
f8 a f19: min="0" para cada uno
Verificar que el formulario impida entrada de números negativos
Probar el formulario en el navegador si es necesario
Agregar min="1900" al campo de búsqueda de año en lista.html
