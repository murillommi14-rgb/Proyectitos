# calificaciones/admin.py
# registro en el admin para revisar/editar rapido

from django.contrib import admin
from .models import Calificacion

@admin.register(Calificacion)
class CalificacionAdmin(admin.ModelAdmin):
    # columnas visibles en el listado del admin
    list_display = ("instrumento", "anio_tributario", "corredor", "estado", "actualizado_en")
    # filtros laterales
    list_filter = ("anio_tributario", "estado", "corredor")
    # buscador
    search_fields = ("instrumento", "corredor")
