# reglas de negocio aca va la famosa suma de factores <= 1
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from decimal import Decimal
import re

def validar_suma_factores_limitada(instance):
    # sumamos f8..f19, si pasa de 1 = error, excepto si estado es INVALIDO
    if instance.estado == 'INVALIDO':
        return
    total = sum([
        instance.f8 or Decimal("0"),
        instance.f9 or Decimal("0"),
        instance.f10 or Decimal("0"),
        instance.f11 or Decimal("0"),
        instance.f12 or Decimal("0"),
        instance.f13 or Decimal("0"),
        instance.f14 or Decimal("0"),
        instance.f15 or Decimal("0"),
        instance.f16 or Decimal("0"),
        instance.f17 or Decimal("0"),
        instance.f18 or Decimal("0"),
        instance.f19 or Decimal("0"),
    ])
    if total > Decimal("1"):
        raise ValidationError(f"La suma de factores 8..19 es {total} y NO puede exceder 1")

# Validadores para campos
corredor_validator = RegexValidator(
    regex=r'^[a-zA-Z0-9\s\-]*$',
    message="El corredor solo puede contener letras, números, espacios y guiones.",
    code='invalid_corredor'
)

instrumento_validator = RegexValidator(
    regex=r'^[a-zA-Z0-9\s\-\/]*$',
    message="El instrumento solo puede contener letras, números, espacios, guiones y barras.",
    code='invalid_instrumento'
)

def validar_anio(value):
    if not (1900 <= value <= 2070):
        raise ValidationError("El año debe estar entre 1900 y 2070.")

def validar_monto(value):
    if value < 0:
        raise ValidationError("El monto no puede ser negativo.")
