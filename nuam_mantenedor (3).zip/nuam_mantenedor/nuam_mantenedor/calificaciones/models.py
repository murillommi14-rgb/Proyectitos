# modelo principal del MVP
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal
from .validators import validar_suma_factores_limitada, corredor_validator, instrumento_validator

class Calificacion(models.Model):
    # estados basicos para el flujo
    ESTADOS = [
        ("BORRADOR", "Borrador"),
        ("EN PROCESO", "En Proceso"),
        ("VIGENTE", "Vigente"),
        ("ANULADA", "Anulada"),
        ("INVALIDO", "Inválido"),
    ]

    corredor = models.CharField(max_length=120, help_text="Nombre Corredor", validators=[corredor_validator])
    instrumento = models.CharField(max_length=120, help_text="Identificador del instrumento", validators=[instrumento_validator])
    anio_tributario = models.IntegerField(verbose_name="Año tributario", help_text="Año tributario", validators=[MinValueValidator(1900), MaxValueValidator(2070)])
    monto = models.DecimalField(max_digits=18, decimal_places=2, default=Decimal("0"), validators=[MinValueValidator(Decimal("0"))])

    # factores 8..19
    f8  = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f9  = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f10 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f11 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f12 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f13 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f14 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f15 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f16 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f17 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f18 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))
    f19 = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True, default=Decimal("0"))

    estado = models.CharField(max_length=12, choices=ESTADOS, default="BORRADOR")

    # timestamps
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-actualizado_en"]  # lo mas reciente se va para arriba
        indexes = [
            models.Index(fields=["corredor"]),
            models.Index(fields=["anio_tributario"]),
            models.Index(fields=["instrumento"]),
            models.Index(fields=["estado"]),
            models.Index(fields=["corredor", "anio_tributario"]),
            models.Index(fields=["instrumento", "estado"]),
        ]

    def clean(self):
        # ejecutamos la regla de negocio ANTES de guardar
        validar_suma_factores_limitada(self)

    def __str__(self):
        return f"{self.instrumento} / {self.anio_tributario} / {self.corredor}"
