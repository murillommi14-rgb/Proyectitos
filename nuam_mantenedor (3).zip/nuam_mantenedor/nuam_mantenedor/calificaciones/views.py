# vistas del modulo, usamos genericas para no escribir de mas
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, FormView
from django.http import HttpResponse
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
import openpyxl
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import pandas as pd
from datetime import datetime
import re
import pdfplumber
from .models import Calificacion
from .forms import CalificacionForm, BulkUploadForm

@method_decorator(login_required, name='dispatch')
class CalificacionListView(ListView):
    # lista con paginacion
    model = Calificacion
    paginate_by = 10
    template_name = "calificaciones/lista.html"

    def get_queryset(self):
        queryset = super().get_queryset()
        anio = self.request.GET.get('anio')
        corredor = self.request.GET.get('corredor')
        if anio:
            queryset = queryset.filter(anio_tributario=anio)
        if corredor:
            queryset = queryset.filter(corredor__icontains=corredor)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter_anio'] = self.request.GET.get('anio', '')
        context['filter_corredor'] = self.request.GET.get('corredor', '')
        return context

@method_decorator(login_required, name='dispatch')
class CalificacionCreateView(CreateView):
    # formulario de creacion (valida reglas en model.clean())
    model = Calificacion
    form_class = CalificacionForm
    success_url = reverse_lazy("calif_list")
    template_name = "calificaciones/crear.html"


@method_decorator(login_required, name='dispatch')
class CalificacionUpdateView(UpdateView):
    # formulario de edicion
    model = Calificacion
    form_class = CalificacionForm
    success_url = reverse_lazy("calif_list")
    template_name = "calificaciones/crear.html" 


@method_decorator(login_required, name='dispatch')
class CalificacionDeleteView(DeleteView):
    # vista de eliminacion
    model = Calificacion
    success_url = reverse_lazy("calif_list")
    template_name = "calificaciones/confirm_delete.html" 


@login_required
def download_template_csv(request):
    import csv
    from django.http import HttpResponse

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="plantilla_calificaciones.csv"'

    writer = csv.writer(response)
    headers = ["corredor", "instrumento", "anio_tributario", "monto", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "estado"]
    writer.writerow(headers)
    # Agregar una fila de muestra
    sample = ["Ejemplo Corredor", "Ejemplo Instrumento", 2023, 1000.00, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, "BORRADOR"]
    writer.writerow(sample)

    return response

@login_required
def download_template_xlsx(request):
    import openpyxl
    from django.http import HttpResponse

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Plantilla Calificaciones"

    headers = ["corredor", "instrumento", "anio_tributario", "monto", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "estado"]
    ws.append(headers)

    # Agregar una fila de muestra
    sample = ["Ejemplo Corredor", "Ejemplo Instrumento", 2023, 1000.00, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, "BORRADOR"]
    ws.append(sample)

    # Formacion
    from openpyxl.styles import Font, Alignment
    header_font = Font(bold=True)
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="plantilla_calificaciones.xlsx"'
    wb.save(response)

    return response

@login_required
def download_template_pdf(request):
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
    from reportlab.lib import colors
    from django.http import HttpResponse

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="plantilla_calificaciones.pdf"'

    doc = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    # Sample data
    data = [
        ["corredor", "instrumento", "anio_tributario", "monto", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "estado"],
        ["Ejemplo Corredor", "Ejemplo Instrumento", 2023, 1000.00, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, "BORRADOR"]
    ]

    # Create table
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))

    elements.append(table)
    doc.build(elements)

    return response

@login_required
def export_excel(request):
    queryset = Calificacion.objects.all()
    anio = request.GET.get('anio')
    corredor = request.GET.get('corredor')
    if anio:
        queryset = queryset.filter(anio_tributario=anio)
    if corredor:
        queryset = queryset.filter(corredor__icontains=corredor)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Calificaciones NUAM"
    headers = ["Instrumento", "Año Tributario", "Corredor", "Monto", "Estado", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "Actualizado"]
    ws.append(headers)
    for c in queryset:
        ws.append([
            c.instrumento, c.anio_tributario, c.corredor, float(c.monto), c.estado,
            float(c.f8), float(c.f9), float(c.f10), float(c.f11), float(c.f12), float(c.f13),
            float(c.f14), float(c.f15), float(c.f16), float(c.f17), float(c.f18), float(c.f19),
            c.actualizado_en.strftime("%Y-%m-%d %H:%M")
        ])

    # Formacion
    from openpyxl.styles import Font, Alignment
    header_font = Font(bold=True)
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=calificaciones_nuam.xlsx'
    wb.save(response)
    return response


@login_required
def export_pdf(request):
    queryset = Calificacion.objects.all()
    anio = request.GET.get('anio')
    corredor = request.GET.get('corredor')
    if anio:
        queryset = queryset.filter(anio_tributario=anio)
    if corredor:
        queryset = queryset.filter(corredor__icontains=corredor)

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=calificaciones_nuam.pdf'
    p = canvas.Canvas(response, pagesize=letter)
    width, height = letter

    # Titulo
    p.setFont("Helvetica-Bold", 16)
    p.drawString(200, height - 50, "Calificaciones Tributarias - NUAM")
    p.setFont("Helvetica", 12)
    p.drawString(50, height - 80, f"Total registros: {queryset.count()}")

    y = height - 100
    p.setFont("Helvetica-Bold", 10)
    p.drawString(50, y, "Instrumento")
    p.drawString(150, y, "Año")
    p.drawString(200, y, "Corredor")
    p.drawString(300, y, "Monto")
    p.drawString(380, y, "Estado")
    y -= 15

    p.setFont("Helvetica", 9)
    for c in queryset:
        if y < 50:
            p.showPage()
            y = height - 50
            p.setFont("Helvetica-Bold", 10)
            p.drawString(50, y, "Instrumento")
            p.drawString(150, y, "Año")
            p.drawString(200, y, "Corredor")
            p.drawString(300, y, "Monto")
            p.drawString(380, y, "Estado")
            y -= 15
            p.setFont("Helvetica", 9)
        p.drawString(50, y, str(c.instrumento)[:20])
        p.drawString(150, y, str(c.anio_tributario))
        p.drawString(200, y, str(c.corredor)[:30])
        p.drawString(300, y, f"${c.monto}")
        p.drawString(380, y, c.estado)
        y -= 12

    p.save()
    return response


@method_decorator(login_required, name='dispatch')
class BulkUploadView(FormView):
    template_name = "calificaciones/bulk_upload.html"
    form_class = BulkUploadForm
    success_url = reverse_lazy("calif_list")

    def form_valid(self, form):
        files = self.request.FILES.getlist('file')
        total_calificaciones = 0
        for file in files:
            try:
                if file.name.endswith('.csv'):
                    df = pd.read_csv(file)
                elif file.name.endswith(('.xlsx', '.xls')):
                    df = pd.read_excel(file)
                elif file.name.endswith('.pdf'):
                    with pdfplumber.open(file) as pdf:
                        page = pdf.pages[0]
                        table = page.extract_table()
                        if table:
                            df = pd.DataFrame(table[1:], columns=table[0])
                        else:
                            messages.error(self.request, f"No se encontró tabla en el PDF {file.name}.")
                            continue
                else:
                    messages.error(self.request, f"Formato de archivo no soportado para {file.name}. Usa CSV, XLSX o PDF.")
                    continue

                # Solo acepta columnas con nombre
                required_columns = ['corredor', 'instrumento', 'anio_tributario', 'monto', 'f8', 'f9', 'f10', 'f11', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18', 'f19']
                if not all(col in df.columns for col in required_columns):
                    messages.error(self.request, f"El archivo {file.name} no tiene las columnas requeridas. Descarga la plantilla y úsala como base.")
                    continue

                calificaciones = []
                for _, row in df.iterrows():
                    try:
                        corredor_val = str(row['corredor']).strip()
                        corredor_val = re.sub(r'[^a-zA-Z0-9\s\-]', '', corredor_val)
                        instrumento_val = str(row['instrumento']).strip()
                        instrumento_val = re.sub(r'[^a-zA-Z0-9\s\-\/]', '', instrumento_val)
                        anio_val = row['anio_tributario']
                        try:
                            anio_tributario_val = int(float(anio_val)) if anio_val else 0
                        except:
                            anio_tributario_val = 0
                        if anio_tributario_val <= 0 or anio_tributario_val > 2070:
                            anio_tributario_val = datetime.now().year
                        monto_val = row['monto']
                        try:
                            monto_val = float(monto_val) if monto_val else 0
                        except:
                            monto_val = 0
                        if monto_val < 0:
                            monto_val = 0
                        estado_val = str(row.get('estado', 'BORRADOR')).strip() or 'BORRADOR'
                        if estado_val not in ['BORRADOR', 'EN PROCESO', 'VIGENTE', 'ANULADA', 'INVALIDO']:
                            estado_val = 'BORRADOR'

                        def get_float(val, default=0):
                            try:
                                if pd.isna(val) or val == '':
                                    return default
                                return float(val)
                            except:
                                return default

                        f8_val = get_float(row['f8'])
                        f9_val = get_float(row['f9'])
                        f10_val = get_float(row['f10'])
                        f11_val = get_float(row['f11'])
                        f12_val = get_float(row['f12'])
                        f13_val = get_float(row['f13'])
                        f14_val = get_float(row['f14'])
                        f15_val = get_float(row['f15'])
                        f16_val = get_float(row['f16'])
                        f17_val = get_float(row['f17'])
                        f18_val = get_float(row['f18'])
                        f19_val = get_float(row['f19'])

                        # Chequea la suma de los factores
                        total_factores = f8_val + f9_val + f10_val + f11_val + f12_val + f13_val + f14_val + f15_val + f16_val + f17_val + f18_val + f19_val
                        if total_factores > 1:
                            estado_val = 'INVALIDO'
                        else:
                            # Normaliza factores cuando la suma es = 1 if total > 0
                            if total_factores > 0:
                                f8_val /= total_factores
                                f9_val /= total_factores
                                f10_val /= total_factores
                                f11_val /= total_factores
                                f12_val /= total_factores
                                f13_val /= total_factores
                                f14_val /= total_factores
                                f15_val /= total_factores
                                f16_val /= total_factores
                                f17_val /= total_factores
                                f18_val /= total_factores
                                f19_val /= total_factores

                        calif = Calificacion(
                            corredor=corredor_val,
                            instrumento=instrumento_val,
                            anio_tributario=anio_tributario_val,
                            monto=monto_val,
                            f8=f8_val,
                            f9=f9_val,
                            f10=f10_val,
                            f11=f11_val,
                            f12=f12_val,
                            f13=f13_val,
                            f14=f14_val,
                            f15=f15_val,
                            f16=f16_val,
                            f17=f17_val,
                            f18=f18_val,
                            f19=f19_val,
                            estado=estado_val
                        )
                        calificaciones.append(calif)
                    except Exception as e:
                        messages.warning(self.request, f"Error en fila {_+1} del archivo {file.name}: {str(e)}")
                        continue

                Calificacion.objects.bulk_create(calificaciones)
                total_calificaciones += len(calificaciones)
                messages.success(self.request, f"Se cargaron {len(calificaciones)} calificaciones del archivo {file.name}.")
            except Exception as e:
                messages.error(self.request, f"Error al procesar el archivo {file.name}: {str(e)}")
                continue

        if total_calificaciones > 0:
            messages.success(self.request, f"Total calificaciones cargadas: {total_calificaciones}.")
        else:
            messages.warning(self.request, "No se cargaron calificaciones.")

        return super().form_valid(form)
