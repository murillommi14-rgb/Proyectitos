# formulario basado en modelo (para crear/editar rapido)
from django import forms
from .models import Calificacion

class CalificacionForm(forms.ModelForm):
    class Meta:
        model = Calificacion
        fields = [
            "corredor","instrumento","anio_tributario","monto",
            "f8","f9","f10","f11","f12","f13","f14","f15","f16","f17","f18","f19",
            "estado",
        ]
        widgets = {
            "corredor": forms.TextInput(attrs={'autocomplete': 'off'}),
            "instrumento": forms.TextInput(attrs={'autocomplete': 'off'}),
            "estado": forms.Select(),
            "anio_tributario": forms.NumberInput(attrs={'min': '1900', 'max': '2070'}),
            "monto": forms.NumberInput(attrs={'min': '0'}),
            "f8": forms.NumberInput(attrs={'min': '0'}),
            "f9": forms.NumberInput(attrs={'min': '0'}),
            "f10": forms.NumberInput(attrs={'min': '0'}),
            "f11": forms.NumberInput(attrs={'min': '0'}),
            "f12": forms.NumberInput(attrs={'min': '0'}),
            "f13": forms.NumberInput(attrs={'min': '0'}),
            "f14": forms.NumberInput(attrs={'min': '0'}),
            "f15": forms.NumberInput(attrs={'min': '0'}),
            "f16": forms.NumberInput(attrs={'min': '0'}),
            "f17": forms.NumberInput(attrs={'min': '0'}),
            "f18": forms.NumberInput(attrs={'min': '0'}),
            "f19": forms.NumberInput(attrs={'min': '0'}),
        }
        labels = {
            "f8": "Factor 8 (%)",
            "f9": "Factor 9 (%)",
            "f10": "Factor 10 (%)",
            "f11": "Factor 11 (%)",
            "f12": "Factor 12 (%)",
            "f13": "Factor 13 (%)",
            "f14": "Factor 14 (%)",
            "f15": "Factor 15 (%)",
            "f16": "Factor 16 (%)",
            "f17": "Factor 17 (%)",
            "f18": "Factor 18 (%)",
            "f19": "Factor 19 (%)",
        }

class BulkUploadForm(forms.Form):
    file = forms.FileField(label="Archivos CSV o XLSX", help_text="Sube uno o más archivos con las calificaciones", widget=forms.ClearableFileInput(attrs={'multiple': True}))
