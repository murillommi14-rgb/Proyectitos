# TODO: Implementar redirección diferenciada en login

Agregar LoginView personalizado en core/views.py que redirija basado en tipo de usuario (admin a /admin/, trabajador a calificaciones)
Actualizar nuam_mantenedor/urls.py para usar la vista personalizada en lugar de auth_views.LoginView
Modificar HomeView para redirigir a login si usuario no autenticado
Cambiar la URL raíz para que sea el login (inicio del sistema)
Ocultar navbar y footer en páginas no autenticadas (login)
Cambiar redirección de admin a la página home del sistema en lugar de /admin/
Modificar página home para mostrar solo opciones de calificaciones y administración, sin navbar/footer/bulk upload
