# Explicación del Código del Proyecto NUAM Mantenedor

Este documento explica qué hace cada parte del código del proyecto Django "NUAM Mantenedor", un sistema para gestionar calificaciones (posiblemente relacionadas con tributos o evaluaciones).

## Estructura General del Proyecto

- **nuam_mantenedor/**: Directorio raíz del proyecto Django.
- **manage.py**: Script para ejecutar comandos de Django (ej. runserver, migrate).
- **db.sqlite3**: Base de datos SQLite.
- **requirements.txt**: Lista de dependencias Python.
- **templates/**: Plantillas HTML globales.
- **static/**: Archivos estáticos (CSS, JS, imágenes).
- **Dockerfile**, **docker-compose.yml**, etc.: Configuración para contenedores Docker.

## Configuración Principal (nuam_mantenedor/settings.py)

- **BASE_DIR**: Ruta base del proyecto.
- **SECRET_KEY**: Clave secreta para seguridad (cambiar en producción).
- **DEBUG**: Modo debug activado (desactivar en producción).
- **ALLOWED_HOSTS**: Hosts permitidos ( "*" para desarrollo).
- **INSTALLED_APPS**: Apps instaladas, incluyendo Django built-in, nuestras apps (core, calificaciones, auditoria) y third-party (django_bootstrap5).
- **MIDDLEWARE**: Capas que procesan cada request/response, incluyendo nuestro middleware para capturar el usuario actual.
- **ROOT_URLCONF**: Archivo de URLs principal.
- **TEMPLATES**: Configuración de plantillas, busca en /templates y dentro de cada app.
- **DATABASES**: Configuración de BD (SQLite por defecto).
- **AUTH_PASSWORD_VALIDATORS**: Validadores de contraseñas.
- **LANGUAGE_CODE, TIME_ZONE**: Idioma y zona horaria (es-cl, Santiago).
- **STATIC_URL, STATICFILES_DIRS**: Configuración de archivos estáticos.

## URLs Principales (nuam_mantenedor/urls.py)

- **admin/**: Panel de administración de Django.
- **"" (home)**: Vista de inicio (HomeView).
- **calificaciones/**: Incluye URLs del módulo calificaciones.
- **accounts/login/**, **accounts/logout/**: Vistas de login/logout usando Django auth.

## App: Core

### core/models.py
- Vacío por ahora, pero puede contener modelos globales.

### core/views.py
- **HomeView**: Vista de la página de inicio, probablemente muestra un resumen o bienvenida.

### core/middleware.py
- **CurrentRequestMiddleware**: Middleware para almacenar el request actual en un hilo local, útil para auditoría (saber quién hizo qué).

## App: Calificaciones

### calificaciones/models.py
- **Calificacion**: Modelo principal.
  - **corredor**: CharField, corredor responsable.
  - **instrumento**: CharField, identificador del instrumento.
  - **anio_tributario**: PositiveIntegerField, año tributario.
  - **monto**: DecimalField, monto.
  - **f8-f19**: DecimalFields, factores (probablemente para cálculos).
  - **estado**: CharField con choices (BORRADOR, VIGENTE, ANULADA).
  - **creado_en, actualizado_en**: Timestamps.
  - **Meta**: Ordena por actualizado_en descendente, índices en corredor y anio_tributario.
  - **clean()**: Valida reglas de negocio antes de guardar.
  - **__str__**: Representación string.

### calificaciones/forms.py
- **CalificacionForm**: Formulario basado en el modelo Calificacion.
- **BulkUploadForm**: Formulario para subir archivos CSV/XLSX.

### calificaciones/views.py
- **CalificacionListView**: Lista calificaciones con paginación, filtros por anio y corredor.
- **CalificacionCreateView**: Crea nuevas calificaciones usando el formulario.
- **export_excel**: Función para exportar calificaciones filtradas a Excel.
- **export_pdf**: Función para exportar a PDF.
- **BulkUploadView**: Vista para carga masiva desde CSV/XLSX usando pandas.

### calificaciones/urls.py
- URLs para lista, crear, exportar Excel/PDF, carga masiva.

### calificaciones/validators.py
- **validar_suma_factores_limitada**: Validador que asegura que la suma de factores f8-f19 no exceda un límite.

## App: Auditoria

### auditoria/models.py
- **Auditoria**: Modelo para registrar acciones.
  - Campos: usuario, accion, modelo, objeto_id, cambios, ip, user_agent, timestamp.

### auditoria/signals.py
- Señales para crear registros de auditoría en cambios de modelos.

### auditoria/admin.py
- Configuración del admin para Auditoria.

## Plantillas (templates/)

- **base.html**: Plantilla base con Bootstrap, navegación.
- **core/home.html**: Página de inicio.
- **calificaciones/lista.html**: Lista de calificaciones con filtros, botones de exportar.
- **calificaciones/crear.html**: Formulario de creación.
- **calificaciones/bulk_upload.html**: Formulario de carga masiva.
- **registration/login.html**: Página de login.

## Docker y Despliegue

- **Dockerfile**: Construye imagen del proyecto.
- **docker-compose.yml**: Para desarrollo (con BD opcional).
- **docker-compose.prod.yml**: Para producción con nginx y gunicorn.
- **nginx.conf**: Configuración de nginx para servir estáticos y proxy a Django.

## Resumen Funcional

El proyecto es un sistema de gestión de "calificaciones" con:
- CRUD de calificaciones.
- Filtros y exportación.
- Carga masiva.
- Autenticación y auditoría.
- Interfaz con Bootstrap.
- Preparado para Docker.

Cada componente está diseñado para ser modular y escalable.
