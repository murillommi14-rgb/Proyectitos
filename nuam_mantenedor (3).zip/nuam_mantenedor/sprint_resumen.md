
### 1. **Configuración del Entorno y Estructura Básica**
   - Empezamos instalando Python, creando un entorno virtual y configurando Django. Creamos el proyecto "nuam_mantenedor" con tres apps principales: `core` (para la portada), `calificaciones` (el corazón del sistema) y `auditoria` (para rastrear cambios).
   - Configuramos las carpetas para templates (HTML) y static (CSS, JS). Todo listo para empezar a codear.

### 2. **Configuración del Proyecto (settings.py)**
   - Registramos nuestras apps en INSTALLED_APPS.
   - Pusimos el idioma en español chileno y la zona horaria de Santiago.
   - Activamos los templates y archivos estáticos.
   - Agregamos un middleware personalizado para capturar el usuario actual, IP y navegador en cada request. Esto fue clave para la auditoría.

### 3. **Portada y Navegación (App Core)**
   - Creamos la vista `HomeView` en `core/views.py` para la página de inicio.
   - Hicimos el template `home.html` con links al admin y al módulo de calificaciones.
   - Conectamos las URLs principales: `/admin` para el panel de Django, `/` para la portada y `/calificaciones` para el módulo principal.

### 4. **Módulo de Calificaciones (El Núcleo)**
   - **Modelo Calificacion**: Definimos una tabla con campos como corredor, instrumento, año tributario, monto, factores f8 a f19, estado (borrador, vigente, anulada) y timestamps.
   - **Validación de Negocio**: Implementamos una regla: la suma de los factores f8 a f19 no puede exceder 1. Si alguien intenta guardar algo que rompe esto, Django lanza un error.
   - **Formularios y Vistas**: Creamos formularios basados en el modelo y vistas para listar y crear calificaciones.
   - **Templates**: Hicimos plantillas simples para la lista (`lista.html`) y creación (`crear.html`).
   - **Admin**: Registramos el modelo en el admin de Django para gestión fácil.
   - **Migraciones**: Corrimos las migraciones para crear la tabla en la base de datos SQLite.

### 5. **Auditoría (Bitácora Automática)**
   - **Modelo Auditoria**: Una tabla para registrar acciones: usuario, acción (creado, actualizado, eliminado), modelo, ID del objeto, detalles de cambios, IP, user agent y timestamp.
   - **Middleware y Señales**: Usamos middleware para capturar el request actual y señales para que cada cambio en una calificación se registre automáticamente en la auditoría. ¡No hay que acordarse de nada, Django lo hace solo!
   - Registramos la auditoría en el admin para revisarla fácilmente.

### 6. **Mejoras Recientes (Tareas Completadas)**
   - **Prevención de Números Negativos**: Actualizamos el formulario para impedir entradas negativas en campos numéricos (año, monto, factores). Agregamos atributos `min` en los widgets HTML.
   - **Redirección Inteligente en Login**: Implementamos un login personalizado que redirige a los admins a `/admin/` y a los trabajadores a calificaciones. Cambiamos la URL raíz para que sea el login, y ocultamos la navbar en páginas no autenticadas. Ahora la home muestra solo opciones relevantes.

### 7. **Tecnologías y Dependencias**
   - **Backend**: Django 4.2, con SQLite como base de datos.
   - **Librerías**: openpyxl (para Excel), reportlab (para PDF), pandas (para carga masiva), django-bootstrap5 (para estilos), gunicorn (para producción), pdfplumber (para PDFs).
   - **Frontend**: Bootstrap para una interfaz responsive y moderna.
   - **Despliegue**: Docker con docker-compose para desarrollo y producción, nginx para servir estáticos.

### 8. **Estado Actual**
   - La portada funciona en `/`.
   - Se pueden crear y listar calificaciones en `/calificaciones/`.
   - La validación de factores funciona perfectamente.
   - La auditoría registra todo: usuario, IP, navegador y acción.
   - Todo probado y corriendo sin problemas.
   - El sistema está autenticado: solo usuarios logueados acceden.

## Lo Que Nos Queda por Hacer (Próximos Sprints)

- **Filtros Avanzados**: Agregar filtros por año o corredor en la lista de calificaciones.
- **Exportación**: Funcionalidades para exportar datos a Excel o PDF.
- **Carga Masiva**: Permitir subir archivos CSV o XLSX para importar múltiples calificaciones.
- **Roles y Permisos**: Implementar diferentes roles (admin, analista, auditor) con permisos específicos.
- **Mejoras en la Interfaz**: Pulir el diseño, hacerla más intuitiva y atractiva.
- **Docker Completo**: Asegurar que todo el equipo pueda usar Docker para desarrollo y preparar el despliegue en producción.

## Instrucciones para Empezar (Setup)

Para que cualquiera pueda correr el proyecto en otro PC:
1. Instala Python 3.11+.
2. Crea un entorno virtual: `python -m venv venv`.
3. Actívalo: `venv\Scripts\activate` (Windows) o `source venv/bin/activate` (Linux/Mac).
4. Instala dependencias: `pip install -r requirements.txt`.
5. Entra al directorio: `cd nuam_mantenedor`.
6. Migra la BD: `python manage.py migrate`.
7. Corre el servidor: `python manage.py runserver`.
   - Accede en http://127.0.0.1:8000/.
   - Para otros dispositivos: `python manage.py runserver 0.0.0.0:8000`.

Si hay problemas con la BD, borra `db.sqlite3` y vuelve a migrar.

## Conceptos Clave para Entender el Proyecto

- **Vista**: Función o clase que decide qué mostrar en una URL (ej. HomeView para la portada).
- **Template**: Archivo HTML para el contenido visible (ej. home.html).
- **Modelo**: Representación de una tabla en BD, escrita en Python (ej. Calificacion).
- **Migraciones**: Archivos para actualizar la BD cuando cambias modelos.
- **Admin**: Panel de Django para manejar datos sin codear extra.
- **Señales**: "Ganchos" que se activan en cambios de BD, como registrar auditoría.
- **Middleware**: "Filtro" que corre en cada request, capturando info como usuario e IP.
- **Validación de Negocio**: Reglas inventadas que el sistema debe seguir (ej. suma de factores ≤ 1).

